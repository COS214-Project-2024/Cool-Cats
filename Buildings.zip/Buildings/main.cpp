#include <iostream>
#include <vector>
using namespace std;

#include "Structure.h"
#include "StructureGroup.h"
#include "StructureDecorator.h"
#include "CStructIterator.h"
#include "SatisfactionEnhancer.h"
#include "MaintenanceCostReducer.h"
#include "ResourceEfficiencyEnhancer.h"
#include "BasicStructure.h"
#include "StructureIterator.h"


void testStructure(){


}

int main(){
    cout << "Testing << endl";

    return 0;
}
